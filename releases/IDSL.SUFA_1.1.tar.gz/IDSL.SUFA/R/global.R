utils::globalVariables(c("UFA_memeory_variables", "IUPAC_Isotopes", "intensity_cutoff"))
